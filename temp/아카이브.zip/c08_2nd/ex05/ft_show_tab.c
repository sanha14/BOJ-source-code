/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_show_tab.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: johyoon <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/23 19:21:49 by johyoon           #+#    #+#             */
/*   Updated: 2022/02/24 20:56:35 by johyoon          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_stock_str.h"
#include <unistd.h>
void	ft_putchar_(char c)
{
	write(1, &c, 1);
}

void	ft_putstr_(char *str)
{
	int		i;

	i = 0;
	while (str[i])
	{
		ft_putchar_(str[i]);
		i++;
	}
}

void	ft_putnbr_(int nb)
{
	unsigned int	nbr;

	if (nb < 0)
	{
		ft_putchar_('-');
		nbr = nb * -1;
	}
	else
		nbr = nb;
	if (nbr >= 10)
		ft_putnbr_(nbr / 10);
	ft_putchar_(nbr % 10 + 48);
}

void	ft_show_tab(struct s_stock_str *par)
{
	int		i;

	i = 0;
	while (par[i].str != 0)
	{
		ft_putstr_(par[i].str);
		ft_putchar_('\n');
		ft_putnbr_(par[i].size);
		ft_putchar_('\n');
		ft_putstr_(par[i].copy);
		ft_putchar_('\n');
		i++;
	}
}
