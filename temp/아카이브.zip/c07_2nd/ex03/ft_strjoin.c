/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: johyoon <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/21 17:33:55 by johyoon           #+#    #+#             */
/*   Updated: 2022/02/22 20:23:54 by johyoon          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	c;

	c = 0;
	while (str[c] != '\0')
		c++;
	return (c);
}

char	*ft_strcat(char	*dest, char	*src)
{
	int	i;
	int	n;

	i = 0;
	n = 0;
	while (dest[i] != '\0')
		i++;
	while (src[n] != '\0')
	{
		dest[i] = src[n];
		i++;
		n++;
	}
	dest[i] = '\0';
	return (dest);
}

int	ft_total_len(char **strs, int size, char *sep)
{
	int	i;
	int	total_len;

	i = 0;
	total_len = 0;
	while (i < size)
	{
		total_len = total_len + ft_strlen(strs[i]);
		i++;
	}
	total_len += ((size - 1) * ft_strlen(sep)) + 1;
	return (total_len);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		i;
	int		total_len;
	char	*one_str;

	i = 0;
	total_len = ft_total_len(strs, size, sep);
	one_str = (char *)malloc(sizeof(char) * (total_len));
	*one_str = 0;
	while (i < size)
	{
		ft_strcat(one_str, strs[i]);
		if (i < size - 1)
			ft_strcat(one_str, sep);
		i++;
	}
	one_str[total_len] = '\0';
	return (one_str);
}
