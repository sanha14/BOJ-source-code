#include <stdio.h>

void	ft_rev_int_tab(int	*tab, int	size);

void	prt_arr(int	*arr, int	size)
{
	int	i;

	i = 0;
	while (i < size)
	{
		printf("%d\n", arr[i]);
		i++;
	}
}

int	main(void)
{
	int	size;

	int tab[] = {1, 2, 3, 4, 5};
	size = 5;
	printf("original: ");
	prt_arr(tab, size);
	printf("reverse: ");
	ft_rev_int_tab(tab, size);
	prt_arr(tab, size);
}
