#include <stdio.h>

void	ft_swap(int *a, int *b);

int	main(void)
{
	int	i;
	int	j;

	i = 42;
	j = 24;
	printf("%d %d\n", i, j);
	ft_swap(&i, &j);
	printf("%d %d", i, j);
}
