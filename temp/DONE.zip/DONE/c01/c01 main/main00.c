#include <stdio.h>

void	ft_ft(int *nbr);

int	main(void)
{
	int	nbr;
	int	*nbr2;

	nbr = 11;
	nbr2 = &nbr;
	ft_ft(nbr2);
	printf("%d", nbr);
	return(0);
}
