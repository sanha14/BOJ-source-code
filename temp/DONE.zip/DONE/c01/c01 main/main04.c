#include <stdio.h>

void	ft_ultimate_div_mod(int	*a, int	*b);

int	main(void)
{
	int a = 35;
	int b = 8;
	ft_ultimate_div_mod(&a, &b);
	printf("%d %d", a, b);
}
