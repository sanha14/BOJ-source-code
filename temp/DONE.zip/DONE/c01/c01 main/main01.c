#include <stdio.h>

void	ft_ultimate_ft(int *********nbr);

int	main(void)
{
	int	nbr;
	int	*nbr9;
	int	**nbr8;
	int	***nbr7;
	int	****nbr6;
	int	*****nbr5;
	int	******nbr4;
	int	*******nbr3;
	int	********nbr2;
	int	*********nbr1;

	nbr9 = &nbr;
	nbr8 = &nbr9;
	nbr7 = &nbr8;
	nbr6 = &nbr7;
	nbr5 = &nbr6;
	nbr4 = &nbr5;
	nbr3 = &nbr4;
	nbr2 = &nbr3;
	nbr1 = &nbr2;
	ft_ultimate_ft(nbr1);
	printf("%d\n", nbr);	
	return (0);
}
