#include <stdio.h>

void	ft_putstr(char	*str);

int	main(void)
{
	char str[] = "hello world!";
	char *Pstr;
	Pstr = str;
	ft_putstr(Pstr);
}
