#include <stdio.h>

void	ft_sort_int_tab(int	*tab, int	size);

int	main(void)
{
	int	arr[6] = {1,23,4,7,31,17};
	int size = 6;
	int i = 0;

	printf("before: ");
	while (i < size)
	{
		printf("%d ", arr[i]);
		i++;
	}
	ft_sort_int_tab(arr, size);
	printf("\nafter: ");
	i = 0;
	while (i < size)
	{
		printf("%d ", arr[i]);
		i++;
	}
}
