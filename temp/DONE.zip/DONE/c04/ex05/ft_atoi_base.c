/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: johyoon <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/17 16:13:29 by johyoon           #+#    #+#             */
/*   Updated: 2022/02/19 18:14:10 by johyoon          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_invalid_arg(char *base)
{
	int	i;
	int	j;

	i = -1;
	while (base[++i] != '\0')
	{
		if (base[i] == '+' || base[i] == '-')
			return (0);
		if (('\b' <= base[i] && base[i] <= '\r') || (base[i] == ' '))
			return (0);
		if (base[i + 1] != '\0')
			if (base[i] == base[i + 1])
				return (0);
	}
	if (i <= 1)
		return (0);
	return (1);
}

int	match_index(char	c, char	*base)
{
	int	i;

	i = 0;
	while (base[i] != '\0')
	{
		if (c == base[i])
			return (i);
		i++;
	}
	return (-1);
}

int	ft_atoi_sign(char *str, int *i)
{
	int	s;

	s = 1;
	while (str[*i] <= ' ')
		(*i)++;
	while (str[*i] == '-' || str[*i] == '+')
	{
		if (str[(*i)++] == '-')
			s *= -1;
	}
	return (s);
}

int	ft_atoi_base(char	*str, char	*base)
{
	unsigned int	len;
	int				s;
	int				res;
	int				i;

	len = 0;
	i = 0;
	res = 0;
	s = 1;
	while (base[len] != '\0')
		len++;
	if (ft_invalid_arg(base) == 0)
		return (0);
	s = ft_atoi_sign(str, &i);
	while (match_index(str[i], base) != -1)
	{
		res = res * len;
		res += match_index(str[i], base);
		i++;
	}
	return (res * s);
}
