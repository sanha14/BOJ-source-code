/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: johyoon <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/16 19:49:46 by johyoon           #+#    #+#             */
/*   Updated: 2022/02/19 17:47:38 by johyoon          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	ft_invalid_arg(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i] != '\0')
	{
		if (base[i] == '+' || base[i] == '-')
			return (0);
		i++;
	}
	i = -1;
	while (base[++i] != '\0')
	{
		j = -1;
		while (base[++j] != '\0')
			if (base[i] == base[j] && i != j)
				return (0);
	}
	if (i <= 1)
		return (0);
	return (1);
}

void	ft_convert_Tobase(long long nbr, char *base, int size)
{
	if (nbr < 0)
	{
		write (1, "-", 1);
		nbr *= -1;
	}
	if (nbr < size)
		ft_putchar(base[nbr]);
	else
	{
		ft_convert_Tobase(nbr / size, base, size);
		ft_convert_Tobase(nbr % size, base, size);
	}
}

void	ft_putnbr_base(int	nbr, char	*base)
{
	int	s;

	s = 0;
	if (ft_invalid_arg(base) == 1)
	{
		while (base[s] != '\0')
			s++;
		ft_convert_Tobase((long long)nbr, base, s);
	}
}
