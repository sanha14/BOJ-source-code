/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: johyoon <johyoon@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/08 21:10:29 by johyoon           #+#    #+#             */
/*   Updated: 2022/02/10 19:24:36 by johyoon          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	printnbr(char arr[], int n)
{
	write(1, arr, n);
	if (arr[0] == 10 - n + '0' && arr[n - 1] == '9')
		return ;
	write(1, ", ", 2);
}

void	ft_print_combn(int n)
{
	char	arr[10];
	int		i;

	arr[0] = '0';
	i = 1;
	while (i < n)
	{
		arr[i] = arr[i - 1] + 1;
		i++;
	}
	printnbr(arr, n);
	while (arr[0] != 10 - n + '0' || arr[n - 1] != '9')
	{
		i = n - 1;
		while (arr[i] == '9' - (n - 1 - i))
			i--;
		arr[i]++;
		i++;
		while (i < n)
		{
			arr[i] = arr[i - 1] + 1;
			i++;
		}
		printnbr(arr, n);
	}
}
