/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: johyoon <johyoon@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/08 21:11:09 by johyoon           #+#    #+#             */
/*   Updated: 2022/02/10 19:24:38 by johyoon          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char	a)
{
	write(1, &a, 1);
}

void	printnbr(long	nb)
{
	char	a;

	if (nb < 10)
	{
		a = nb + '0';
		write(1, &a, 1);
		return ;
	}
	else
		printnbr(nb / 10);
	a = (nb % 10) + '0';
	write(1, &a, 1);
}

void	ft_putnbr(int	nb)
{
	long	b;

	b = nb;
	if (nb < 0)
	{
		b *= -1;
		ft_putchar('-');
	}
	printnbr(b);
}
