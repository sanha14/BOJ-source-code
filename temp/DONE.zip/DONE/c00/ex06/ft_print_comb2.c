/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: johyoon <johyoon@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/08 21:11:42 by johyoon           #+#    #+#             */
/*   Updated: 2022/02/10 19:24:44 by johyoon          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	putnbr(int	a, int	b)
{
	char	arr1[2];

	arr1[0] = a / 10 + '0';
	arr1[1] = a % 10 + '0';
	write(1, arr1, 2);
	write(1, " ", 1);
	arr1[0] = b / 10 + '0';
	arr1[1] = b % 10 + '0';
	write(1, arr1, 2);
	if (a == 98 && b == 99)
		return ;
	write(1, ", ", 2);
}

void	ft_print_comb2(void)
{
	int	a;
	int	b;

	a = 0;
	while (a <= 98)
	{
		b = a + 1;
		while (b <= 99)
		{
			putnbr(a, b);
			b++;
		}
		a++;
	}
}
