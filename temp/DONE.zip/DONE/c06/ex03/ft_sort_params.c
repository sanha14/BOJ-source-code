/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: johyoon <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/20 11:22:08 by johyoon           #+#    #+#             */
/*   Updated: 2022/02/20 17:27:40 by johyoon          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	ft_strcmp(char	*s1, char	*s2)
{
	char	c1;
	char	c2;

	while (1)
	{
		c1 = *s1;
		c2 = *s2;
		if (c1 != c2)
			return (c1 - c2);
		if (!c1)
			return (0);
		s1++;
		s2++;
	}
	return (0);
}

void	ft_putstr(char *str)
{
	int	c;

	c = 0;
	while (str[c] != '\0')
	{
		write(1, &str[c], 1);
		c++;
	}
	write(1, "\n", 1);
}

int	main(int argc, char **argv)
{
	int		i;
	int		d;
	char	*tmp;

	i = 1;
	d = 0;
	while (d++ < argc)
	{
		i = 0;
		while (++i + 1 < argc)
		{
			if (ft_strcmp(argv[i], argv[i + 1]) > 0)
			{
				tmp = argv[i];
				argv[i] = argv[i + 1];
				argv[i + 1] = tmp;
			}
		}
	}
	i = 1;
	while (i < argc)
	{
		ft_putstr(argv[i++]);
	}
	return (0);
}
