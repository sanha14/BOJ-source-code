/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: johyoon <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/20 21:52:02 by johyoon           #+#    #+#             */
/*   Updated: 2022/02/22 09:52:35 by johyoon          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_prime2(int nb)
{
	int	a;

	a = 2;
	if (nb <= 1)
		return (0);
	while (a <= nb / a)
	{
		if ((nb % a) == 0)
			return (0);
		a++;
	}
	return (1);
}

int	ft_find_next_prime(int	nb)
{
	if (nb <= 2)
		return (2);
	while (ft_is_prime2(nb) == 0)
	{
		nb++;
	}
	return (nb);
}
